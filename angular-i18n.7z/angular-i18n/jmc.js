require('./angular-locale_jmc');
module.exports = 'ngLocale';
