require('./angular-locale_ti');
module.exports = 'ngLocale';
