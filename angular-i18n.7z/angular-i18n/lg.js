require('./angular-locale_lg');
module.exports = 'ngLocale';
