require('./angular-locale_ar-lb');
module.exports = 'ngLocale';
