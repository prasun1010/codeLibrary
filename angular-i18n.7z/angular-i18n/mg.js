require('./angular-locale_mg');
module.exports = 'ngLocale';
