require('./angular-locale_en-us');
module.exports = 'ngLocale';
