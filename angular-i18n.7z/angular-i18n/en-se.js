require('./angular-locale_en-se');
module.exports = 'ngLocale';
