require('./angular-locale_fr-dj');
module.exports = 'ngLocale';
