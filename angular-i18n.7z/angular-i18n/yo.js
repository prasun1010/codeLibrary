require('./angular-locale_yo');
module.exports = 'ngLocale';
