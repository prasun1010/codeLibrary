require('./angular-locale_mg-mg');
module.exports = 'ngLocale';
