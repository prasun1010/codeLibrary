require('./angular-locale_ar-ly');
module.exports = 'ngLocale';
