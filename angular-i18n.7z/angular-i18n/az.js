require('./angular-locale_az');
module.exports = 'ngLocale';
