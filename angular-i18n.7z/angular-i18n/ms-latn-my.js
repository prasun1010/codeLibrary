require('./angular-locale_ms-latn-my');
module.exports = 'ngLocale';
