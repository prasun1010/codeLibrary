require('./angular-locale_en-rw');
module.exports = 'ngLocale';
