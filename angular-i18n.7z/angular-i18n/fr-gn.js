require('./angular-locale_fr-gn');
module.exports = 'ngLocale';
