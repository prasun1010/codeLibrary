require('./angular-locale_en-mu');
module.exports = 'ngLocale';
