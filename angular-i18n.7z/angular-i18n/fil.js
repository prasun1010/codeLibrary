require('./angular-locale_fil');
module.exports = 'ngLocale';
