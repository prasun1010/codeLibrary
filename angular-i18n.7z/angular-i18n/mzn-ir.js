require('./angular-locale_mzn-ir');
module.exports = 'ngLocale';
