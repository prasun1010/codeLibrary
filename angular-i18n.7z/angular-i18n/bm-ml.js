require('./angular-locale_bm-ml');
module.exports = 'ngLocale';
