require('./angular-locale_pt-st');
module.exports = 'ngLocale';
