require('./angular-locale_zu-za');
module.exports = 'ngLocale';
