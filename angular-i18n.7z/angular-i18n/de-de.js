require('./angular-locale_de-de');
module.exports = 'ngLocale';
