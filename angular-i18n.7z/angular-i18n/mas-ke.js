require('./angular-locale_mas-ke');
module.exports = 'ngLocale';
