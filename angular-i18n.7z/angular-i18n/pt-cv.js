require('./angular-locale_pt-cv');
module.exports = 'ngLocale';
