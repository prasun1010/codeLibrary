require('./angular-locale_es-ic');
module.exports = 'ngLocale';
