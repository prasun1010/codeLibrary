require('./angular-locale_en-ki');
module.exports = 'ngLocale';
