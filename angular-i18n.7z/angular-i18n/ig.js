require('./angular-locale_ig');
module.exports = 'ngLocale';
