require('./angular-locale_ti-et');
module.exports = 'ngLocale';
