require('./angular-locale_dsb-de');
module.exports = 'ngLocale';
