require('./angular-locale_en-dsrt');
module.exports = 'ngLocale';
