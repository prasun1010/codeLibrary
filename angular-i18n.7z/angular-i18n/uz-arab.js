require('./angular-locale_uz-arab');
module.exports = 'ngLocale';
