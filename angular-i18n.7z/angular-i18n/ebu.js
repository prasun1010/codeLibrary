require('./angular-locale_ebu');
module.exports = 'ngLocale';
