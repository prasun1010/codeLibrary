require('./angular-locale_it-it');
module.exports = 'ngLocale';
