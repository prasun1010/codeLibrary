require('./angular-locale_nus-ss');
module.exports = 'ngLocale';
