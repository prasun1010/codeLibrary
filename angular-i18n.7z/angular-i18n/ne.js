require('./angular-locale_ne');
module.exports = 'ngLocale';
