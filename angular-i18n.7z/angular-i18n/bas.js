require('./angular-locale_bas');
module.exports = 'ngLocale';
