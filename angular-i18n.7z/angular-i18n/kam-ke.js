require('./angular-locale_kam-ke');
module.exports = 'ngLocale';
