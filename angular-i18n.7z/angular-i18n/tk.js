require('./angular-locale_tk');
module.exports = 'ngLocale';
