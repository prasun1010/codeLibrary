require('./angular-locale_ru-by');
module.exports = 'ngLocale';
