require('./angular-locale_tn-bw');
module.exports = 'ngLocale';
