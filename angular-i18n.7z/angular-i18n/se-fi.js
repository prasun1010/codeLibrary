require('./angular-locale_se-fi');
module.exports = 'ngLocale';
