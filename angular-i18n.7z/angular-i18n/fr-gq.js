require('./angular-locale_fr-gq');
module.exports = 'ngLocale';
