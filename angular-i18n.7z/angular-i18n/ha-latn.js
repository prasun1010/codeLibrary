require('./angular-locale_ha-latn');
module.exports = 'ngLocale';
