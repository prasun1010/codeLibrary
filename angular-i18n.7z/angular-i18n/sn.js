require('./angular-locale_sn');
module.exports = 'ngLocale';
