require('./angular-locale_ky');
module.exports = 'ngLocale';
