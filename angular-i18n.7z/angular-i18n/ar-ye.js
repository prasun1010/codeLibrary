require('./angular-locale_ar-ye');
module.exports = 'ngLocale';
