require('./angular-locale_en-sh');
module.exports = 'ngLocale';
