require('./angular-locale_en-jm');
module.exports = 'ngLocale';
