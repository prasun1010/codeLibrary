require('./angular-locale_br');
module.exports = 'ngLocale';
