require('./angular-locale_mn-mn');
module.exports = 'ngLocale';
