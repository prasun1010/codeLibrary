require('./angular-locale_es-cr');
module.exports = 'ngLocale';
