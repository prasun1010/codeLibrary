require('./angular-locale_fr-fr');
module.exports = 'ngLocale';
