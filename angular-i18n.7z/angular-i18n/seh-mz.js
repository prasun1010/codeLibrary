require('./angular-locale_seh-mz');
module.exports = 'ngLocale';
