require('./angular-locale_cs-cz');
module.exports = 'ngLocale';
