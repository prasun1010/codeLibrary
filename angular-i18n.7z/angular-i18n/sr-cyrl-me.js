require('./angular-locale_sr-cyrl-me');
module.exports = 'ngLocale';
