require('./angular-locale_nl-sr');
module.exports = 'ngLocale';
