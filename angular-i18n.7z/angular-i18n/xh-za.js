require('./angular-locale_xh-za');
module.exports = 'ngLocale';
