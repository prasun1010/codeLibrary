require('./angular-locale_te-in');
module.exports = 'ngLocale';
