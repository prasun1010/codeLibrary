require('./angular-locale_teo-ke');
module.exports = 'ngLocale';
