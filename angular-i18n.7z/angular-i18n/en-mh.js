require('./angular-locale_en-mh');
module.exports = 'ngLocale';
