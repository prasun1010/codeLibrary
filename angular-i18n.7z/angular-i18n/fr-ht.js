require('./angular-locale_fr-ht');
module.exports = 'ngLocale';
