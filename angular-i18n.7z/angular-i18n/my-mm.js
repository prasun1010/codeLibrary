require('./angular-locale_my-mm');
module.exports = 'ngLocale';
