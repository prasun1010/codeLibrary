require('./angular-locale_tg-cyrl-tj');
module.exports = 'ngLocale';
