require('./angular-locale_fr-sc');
module.exports = 'ngLocale';
