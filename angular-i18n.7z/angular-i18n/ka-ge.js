require('./angular-locale_ka-ge');
module.exports = 'ngLocale';
