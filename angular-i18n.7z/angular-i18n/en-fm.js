require('./angular-locale_en-fm');
module.exports = 'ngLocale';
