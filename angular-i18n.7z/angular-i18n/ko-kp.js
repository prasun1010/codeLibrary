require('./angular-locale_ko-kp');
module.exports = 'ngLocale';
