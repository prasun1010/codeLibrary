require('./angular-locale_az-latn');
module.exports = 'ngLocale';
