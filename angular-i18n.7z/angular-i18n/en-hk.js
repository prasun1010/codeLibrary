require('./angular-locale_en-hk');
module.exports = 'ngLocale';
