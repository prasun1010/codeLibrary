require('./angular-locale_en-tz');
module.exports = 'ngLocale';
