require('./angular-locale_be-by');
module.exports = 'ngLocale';
