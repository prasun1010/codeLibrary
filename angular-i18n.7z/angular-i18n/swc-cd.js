require('./angular-locale_swc-cd');
module.exports = 'ngLocale';
