require('./angular-locale_en-dm');
module.exports = 'ngLocale';
