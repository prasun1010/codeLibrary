require('./angular-locale_ml-in');
module.exports = 'ngLocale';
