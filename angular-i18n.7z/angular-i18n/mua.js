require('./angular-locale_mua');
module.exports = 'ngLocale';
