require('./angular-locale_en-bz');
module.exports = 'ngLocale';
