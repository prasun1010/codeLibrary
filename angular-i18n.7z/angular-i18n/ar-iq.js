require('./angular-locale_ar-iq');
module.exports = 'ngLocale';
