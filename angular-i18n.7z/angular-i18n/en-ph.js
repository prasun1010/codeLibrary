require('./angular-locale_en-ph');
module.exports = 'ngLocale';
