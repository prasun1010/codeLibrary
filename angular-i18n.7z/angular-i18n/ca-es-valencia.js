require('./angular-locale_ca-es-valencia');
module.exports = 'ngLocale';
