require('./angular-locale_lg-ug');
module.exports = 'ngLocale';
