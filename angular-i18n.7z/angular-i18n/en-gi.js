require('./angular-locale_en-gi');
module.exports = 'ngLocale';
