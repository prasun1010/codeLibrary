require('./angular-locale_nmg-cm');
module.exports = 'ngLocale';
