require('./angular-locale_en');
module.exports = 'ngLocale';
