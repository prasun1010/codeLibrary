require('./angular-locale_kab');
module.exports = 'ngLocale';
