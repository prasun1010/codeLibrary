require('./angular-locale_en-gm');
module.exports = 'ngLocale';
