require('./angular-locale_ee');
module.exports = 'ngLocale';
