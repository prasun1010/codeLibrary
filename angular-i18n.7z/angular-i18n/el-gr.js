require('./angular-locale_el-gr');
module.exports = 'ngLocale';
