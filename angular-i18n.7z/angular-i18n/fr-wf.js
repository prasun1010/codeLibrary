require('./angular-locale_fr-wf');
module.exports = 'ngLocale';
