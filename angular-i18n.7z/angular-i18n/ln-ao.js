require('./angular-locale_ln-ao');
module.exports = 'ngLocale';
