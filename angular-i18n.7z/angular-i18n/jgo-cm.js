require('./angular-locale_jgo-cm');
module.exports = 'ngLocale';
