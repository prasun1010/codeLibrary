require('./angular-locale_dje-ne');
module.exports = 'ngLocale';
