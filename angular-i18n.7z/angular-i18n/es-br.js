require('./angular-locale_es-br');
module.exports = 'ngLocale';
