require('./angular-locale_haw');
module.exports = 'ngLocale';
