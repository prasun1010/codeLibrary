require('./angular-locale_gv-im');
module.exports = 'ngLocale';
