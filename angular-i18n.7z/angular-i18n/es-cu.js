require('./angular-locale_es-cu');
module.exports = 'ngLocale';
