require('./angular-locale_ca-ad');
module.exports = 'ngLocale';
