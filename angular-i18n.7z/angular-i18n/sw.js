require('./angular-locale_sw');
module.exports = 'ngLocale';
