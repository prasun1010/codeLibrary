require('./angular-locale_ckb-arab-iq');
module.exports = 'ngLocale';
