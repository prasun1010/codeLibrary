require('./angular-locale_kn');
module.exports = 'ngLocale';
