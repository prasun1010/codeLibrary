require('./angular-locale_pt-tl');
module.exports = 'ngLocale';
