require('./angular-locale_kk-cyrl-kz');
module.exports = 'ngLocale';
