require('./angular-locale_ca-it');
module.exports = 'ngLocale';
