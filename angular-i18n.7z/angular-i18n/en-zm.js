require('./angular-locale_en-zm');
module.exports = 'ngLocale';
