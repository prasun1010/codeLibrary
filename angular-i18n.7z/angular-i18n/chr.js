require('./angular-locale_chr');
module.exports = 'ngLocale';
