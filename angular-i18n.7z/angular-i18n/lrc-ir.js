require('./angular-locale_lrc-ir');
module.exports = 'ngLocale';
