require('./angular-locale_fr-re');
module.exports = 'ngLocale';
