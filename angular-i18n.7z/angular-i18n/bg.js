require('./angular-locale_bg');
module.exports = 'ngLocale';
