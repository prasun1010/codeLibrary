require('./angular-locale_en-au');
module.exports = 'ngLocale';
