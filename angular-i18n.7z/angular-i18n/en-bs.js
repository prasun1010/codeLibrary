require('./angular-locale_en-bs');
module.exports = 'ngLocale';
