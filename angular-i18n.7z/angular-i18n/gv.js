require('./angular-locale_gv');
module.exports = 'ngLocale';
