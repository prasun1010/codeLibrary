require('./angular-locale_fr-cg');
module.exports = 'ngLocale';
