require('./angular-locale_no');
module.exports = 'ngLocale';
