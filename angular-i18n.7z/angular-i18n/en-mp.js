require('./angular-locale_en-mp');
module.exports = 'ngLocale';
