require('./angular-locale_vun');
module.exports = 'ngLocale';
