require('./angular-locale_nso-za');
module.exports = 'ngLocale';
