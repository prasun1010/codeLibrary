require('./angular-locale_ta-my');
module.exports = 'ngLocale';
