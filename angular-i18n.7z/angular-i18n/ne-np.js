require('./angular-locale_ne-np');
module.exports = 'ngLocale';
