require('./angular-locale_cgg');
module.exports = 'ngLocale';
