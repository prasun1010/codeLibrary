require('./angular-locale_ro-md');
module.exports = 'ngLocale';
