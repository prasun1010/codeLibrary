require('./angular-locale_saq');
module.exports = 'ngLocale';
