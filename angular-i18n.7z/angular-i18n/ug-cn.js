require('./angular-locale_ug-cn');
module.exports = 'ngLocale';
