require('./angular-locale_en-sc');
module.exports = 'ngLocale';
