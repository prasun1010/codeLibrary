require('./angular-locale_sv-fi');
module.exports = 'ngLocale';
