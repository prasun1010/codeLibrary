require('./angular-locale_uz-latn');
module.exports = 'ngLocale';
