require('./angular-locale_kw');
module.exports = 'ngLocale';
