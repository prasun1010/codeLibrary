require('./angular-locale_sr-cyrl-rs');
module.exports = 'ngLocale';
