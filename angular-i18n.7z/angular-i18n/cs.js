require('./angular-locale_cs');
module.exports = 'ngLocale';
