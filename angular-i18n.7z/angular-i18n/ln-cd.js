require('./angular-locale_ln-cd');
module.exports = 'ngLocale';
