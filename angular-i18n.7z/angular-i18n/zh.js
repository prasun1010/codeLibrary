require('./angular-locale_zh');
module.exports = 'ngLocale';
