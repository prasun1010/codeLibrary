require('./angular-locale_da-dk');
module.exports = 'ngLocale';
