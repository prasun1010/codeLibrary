require('./angular-locale_sv-se');
module.exports = 'ngLocale';
