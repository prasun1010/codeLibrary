require('./angular-locale_si');
module.exports = 'ngLocale';
