require('./angular-locale_es-ar');
module.exports = 'ngLocale';
