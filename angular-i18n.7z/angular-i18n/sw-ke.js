require('./angular-locale_sw-ke');
module.exports = 'ngLocale';
