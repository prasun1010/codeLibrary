require('./angular-locale_bo');
module.exports = 'ngLocale';
