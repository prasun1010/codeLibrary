require('./angular-locale_he');
module.exports = 'ngLocale';
