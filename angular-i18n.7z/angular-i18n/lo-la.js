require('./angular-locale_lo-la');
module.exports = 'ngLocale';
