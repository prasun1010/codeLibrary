require('./angular-locale_sk-sk');
module.exports = 'ngLocale';
