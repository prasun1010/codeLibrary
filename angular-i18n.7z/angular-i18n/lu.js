require('./angular-locale_lu');
module.exports = 'ngLocale';
