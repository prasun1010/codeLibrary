require('./angular-locale_sw-ug');
module.exports = 'ngLocale';
