require('./angular-locale_fr-ch');
module.exports = 'ngLocale';
