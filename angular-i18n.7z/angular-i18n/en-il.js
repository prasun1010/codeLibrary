require('./angular-locale_en-il');
module.exports = 'ngLocale';
