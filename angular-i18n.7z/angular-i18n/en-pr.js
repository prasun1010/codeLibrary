require('./angular-locale_en-pr');
module.exports = 'ngLocale';
