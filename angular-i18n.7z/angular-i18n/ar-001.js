require('./angular-locale_ar-001');
module.exports = 'ngLocale';
