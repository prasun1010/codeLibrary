require('./angular-locale_ksf');
module.exports = 'ngLocale';
