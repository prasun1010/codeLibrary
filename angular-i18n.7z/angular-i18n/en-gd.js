require('./angular-locale_en-gd');
module.exports = 'ngLocale';
