require('./angular-locale_yav-cm');
module.exports = 'ngLocale';
