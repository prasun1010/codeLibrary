require('./angular-locale_fr-rw');
module.exports = 'ngLocale';
