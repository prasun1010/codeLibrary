require('./angular-locale_lkt');
module.exports = 'ngLocale';
