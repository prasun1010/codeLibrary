require('./angular-locale_ar-kw');
module.exports = 'ngLocale';
