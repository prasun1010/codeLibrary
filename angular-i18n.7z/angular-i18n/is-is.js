require('./angular-locale_is-is');
module.exports = 'ngLocale';
