require('./angular-locale_kkj');
module.exports = 'ngLocale';
