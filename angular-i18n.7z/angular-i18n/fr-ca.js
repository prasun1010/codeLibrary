require('./angular-locale_fr-ca');
module.exports = 'ngLocale';
