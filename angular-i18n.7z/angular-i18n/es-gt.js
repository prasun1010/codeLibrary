require('./angular-locale_es-gt');
module.exports = 'ngLocale';
