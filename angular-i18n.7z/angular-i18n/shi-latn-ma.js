require('./angular-locale_shi-latn-ma');
module.exports = 'ngLocale';
