require('./angular-locale_fo-dk');
module.exports = 'ngLocale';
