require('./angular-locale_sr-latn-xk');
module.exports = 'ngLocale';
