require('./angular-locale_cy-gb');
module.exports = 'ngLocale';
