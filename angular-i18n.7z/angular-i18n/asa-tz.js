require('./angular-locale_asa-tz');
module.exports = 'ngLocale';
