require('./angular-locale_hr-ba');
module.exports = 'ngLocale';
