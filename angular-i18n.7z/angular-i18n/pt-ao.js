require('./angular-locale_pt-ao');
module.exports = 'ngLocale';
