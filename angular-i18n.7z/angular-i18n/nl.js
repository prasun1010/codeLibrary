require('./angular-locale_nl');
module.exports = 'ngLocale';
