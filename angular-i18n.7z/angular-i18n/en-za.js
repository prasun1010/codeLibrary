require('./angular-locale_en-za');
module.exports = 'ngLocale';
