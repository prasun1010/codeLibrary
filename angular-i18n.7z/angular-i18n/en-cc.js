require('./angular-locale_en-cc');
module.exports = 'ngLocale';
