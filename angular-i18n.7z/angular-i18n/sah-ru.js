require('./angular-locale_sah-ru');
module.exports = 'ngLocale';
