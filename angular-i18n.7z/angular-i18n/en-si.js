require('./angular-locale_en-si');
module.exports = 'ngLocale';
