require('./angular-locale_en-lr');
module.exports = 'ngLocale';
